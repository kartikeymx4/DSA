#include<stdio.h>
#define n 5
int queue[n];
int front=-1,rear=-1;
void enq(int x){
    if(front==-1 && rear==-1){
        front=rear=0;
        queue[rear]=x;
    }
    else if(((rear+1)%n)==front){
        printf("queue is full");
    }
    else{
        rear=(rear+1)%n;
        queue[rear]=x;
    }
}
void deq(){
    if(rear==-1 && front==-1){
        printf("Queue is empty");
    }
    else if(front==rear){
        front=rear=-1;
    }
    else{
        front=(front+1)%n;
    }
}
void display(){
    int i=front;
    while(i!=rear){
        printf("%d\t",queue[i]);
        i=(i+1)%n;
    }
    printf("%d",queue[i]);
}
void main(){
    enq(2);
    enq(6);
    enq(8);
    enq(7);
    enq(9);
    display();
    printf("\n");
    deq();
    display();
}