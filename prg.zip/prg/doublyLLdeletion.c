#include<stdio.h>
#include<malloc.h>

struct node{
    int data;
    struct node *pre,*next;
};
struct node *head,*tail,*temp,*newnode;

void create(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->next=newnode->pre=NULL;
    if(head==NULL){
        head=tail=newnode;
    }
    else{
        tail->next=newnode;
        newnode->pre=tail;
        tail=newnode;
    }
}

void display(){
    temp=head;
    while(temp!=NULL){
        printf("->%d",temp->data);
        temp=temp->next;
    }
    printf("\n");
}

void deletebeg(){
    temp=head;
    head->next->pre=NULL;
    head=head->next;
    free(temp);
}

void deleteend(){
    temp=tail;
    tail=tail->pre;
    tail->next=NULL;
    free(temp);
}

void deletepos(){
    int pos;
    printf("Enter position  : ");
    scanf("%d",&pos);
    if(pos<1){
        printf("Invalid ");
    }
    else if(pos==1){
        deletebeg();
    }
    else{
        temp=head;
        int i=1;
        while(i<pos){
            temp=temp->next;
            i++;
        }
        temp->pre->next=temp->next;
        temp->next->pre=temp->pre;
        free(temp);
    }
}

int main(){
    int choice=1;
    while (choice)
    {
        create();
        printf("Do you want to enter more (1/0) ");
        scanf("%d",&choice);
    }
    display();
    printf("delete at beggining\n");
    deletebeg();
    display();
    printf("delete from end\n");
    deleteend();
    display();
    printf("delete at a position \n");
    deletepos();
    display();
    return 0;
}