//create and display linked list
#include<stdio.h>
#include<conio.h>
#include<malloc.h>
struct node{
    int data;
    struct node *next;
};
struct node *head,*temp,*newnode;
//head=0;
void create(){
    newnode=(struct node *)malloc(sizeof(struct node));
    printf("Enter data :");
    scanf("%d",&newnode->data);
    newnode->next=NULL;
    if(head==NULL){
        head=temp=newnode;
    }
    else{
        temp->next=newnode;
        temp=newnode;
    }
}
void display(){
    temp=head;
    while(temp!=NULL){
        printf("->%d",temp->data);
        temp=temp->next;
    }
}
int main(){
    int choice=1;
    while(choice!=0){
        create();
        printf("Do you want to enter more(1/0)");
        scanf("%d",&choice);
    }
    display();
    return 0;
}

