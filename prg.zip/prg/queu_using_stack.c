#include<stdio.h>
#define n 5
int s1[n],s2[n];
int top1=-1;
int top2=-1;
int count=0;
void push1(int x){
    if(top1==n-1)
    printf("Queue is full");
    else{
        top1++;
        s1[top1]=x;
    }
}
void push2(int x1){
    if(top2==n-1)
    printf("Stack is full");
    else{
        top2++;
        s2[top2]=x1;
    }
}
int pop1(){
    return s1[top1--];
}
int pop2(){
    return s2[top2--];
}
void enq(int data){
    push1(data);
    count++;
}
void deq(){
    int i,a,b;
    if(top1==-1 && top2==-1){
        printf("queue is empty");
    }
    else{
        for(i=0;i<count;i++){
            a=pop1();
            push1(a);
        }
        b=pop2();
        printf("%d is poped",b);
        count--;
        for(i=0;i<count;i++){
            a=pop2();
            push1(a);
        }
    }
}
void display(){
    for(int i=0;i<=top1;i++){
        printf("%d\t",s1[i]);
    }    
}

void main(){
    enq(5);
    enq(7);
    enq(2);
    enq(4);
    display();
    printf("\n");
    deq();
    display();
}