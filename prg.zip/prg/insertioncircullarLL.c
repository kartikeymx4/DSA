#include<stdio.h>
#include<malloc.h>

struct node{
    int data;
    struct node *next;
};
struct node *tail,*newnode,*temp;
int cnt=0;
void create(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->next=NULL;
    if(tail==NULL){
        tail=newnode;
        tail->next=newnode;
    }
    else{
        newnode->next=tail->next;
        tail->next=newnode;
        tail=newnode;
    }
}

void display(){
    cnt=0;
    temp=tail->next;
    while(temp->next!=tail->next){
        printf("->%d",temp->data);
        temp=temp->next;
        cnt++;
    }
    printf("->%d",temp->data);
    cnt++;
    printf("\nLength : %d\n",cnt);
}

void insertbeg(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->next=tail->next;
    tail->next=newnode;    
}
void insertend(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->next=tail->next;
    tail->next=newnode;
    tail=newnode;
}
void insertpos(){
    int pos;
    printf("Enter position : ");
    scanf("%d",&pos);
    if(pos<1 || pos>cnt){
        printf("Invalid position");
    }
    else if(pos==1){insertbeg();}
    else{
        newnode=(struct node*)malloc(sizeof(struct node));
        printf("Enter data : ");
        scanf("%d",&newnode->data);
        temp=tail->next;
        int i=1;
        while(i<pos-1){
            temp=temp->next;
            i++;
        }
        newnode->next=temp->next;
        temp->next=newnode;
    }
}
int main(){
    int ch=1;
    while(ch){
        create();
        printf("Do u want to continue(1/0)");
        scanf("%d",&ch);
    }
    display();
    printf("\nInsert at beggining\n" );
    insertbeg();
    display();
    printf("\nInsert at end\n");
    insertend();
    display();
    printf("\nEnter at position\n");
    insertpos();
    display();
    return 0;
}