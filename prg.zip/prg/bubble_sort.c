#include<stdio.h>

void main(){
    int a[]={1,9,4,7,3};
    int n=5,temp,flag;
    printf("\n array\n" );
    for(int k=0;k<n;k++){
        printf("%d\t",a[k]);
    }
    for(int i=0;i<n-1;i++){
        flag=0;
        for(int j=0;j<n-i-1;j++){
            if(a[j]>a[j+1]){
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
                flag=1;
            }
        }
        if(flag==0){
            break;
        }
    }
    printf("\nSorted array\n" );
    for(int k=0;k<n;k++){
        printf("%d\t",a[k]);
    }
}