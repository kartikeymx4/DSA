#include<stdio.h>
#define n 5

int stack[n];
int top=-1;

void push(){
    int val;
    printf("Enter value : ");
    scanf("%d",&val);
    if(top==n-1){
        printf("Overflow");
    }
    else{
        top++;
        stack[top]=val;
    }
}

void pop(){
    int item;
    if(top==-1){
        printf("Underflow");
    }
    else{
        item=stack[top];
        top--;    
    }
    printf("%d deleted",item);
}

void peek(){
    if(top==-1){
        printf("stack is empty");
    }
    else{
        printf("%d",stack[top]);
    }
}

void display(){
    int i;
    for(i=top;i>=0;i--){
        printf("%d\t",stack[i]);
    }
}

void main(){
    push();
    push();
    push();
    push();
    display();
    peek();
    pop();
    display();
}