#include<stdio.h>
#include<limits.h>
#define MAX 100
int idx = -1;

int pqVal[MAX];
int pqPriority[MAX];
int isEmpty(){
    return idx == -1;
}

int isFull(){
    return idx == MAX - 1;
}
void enqueue(int data, int priority)
{
    if(!isFull()){
        if(idx == -1){
            idx++; 
            pqVal[idx] = data;
            pqPriority[idx] = priority;
            return;
        }
        else{
            idx++;
            
            for(int i = idx-1; i >= 0;i--){
                if(pqPriority[i] >= priority){
                    pqVal[i+1] = pqVal[i];
                    pqPriority[i+1] = pqPriority[i];
                }
                else{
                    pqVal[i+1] = data;
                    pqPriority[i+1] = priority;
                    break;
                }
                
            }
        }

    }
}

int peek()
{
    return idx;
}

void dequeue()
{
        idx--;
}


void display(){
    for (int i = 0; i <= idx; i++) {
        printf("(%d, %d)\n",pqVal[i], pqPriority[i]);
    } 
}
int main()
{
    enqueue(25, 1);
    enqueue(10, 10);
    enqueue(15, 50);
    enqueue(20, 100);
    enqueue(30, 5);
    enqueue(40, 7);
    
    printf("Before Dequeue : \n");
    display();
 
    
    dequeue(); 
    dequeue(); 
    
    printf("\nAfter Dequeue : \n");
    display();

    return 0;
}