//deletion in linked list
#include<stdio.h>
#include<malloc.h>

struct node{
    int data;
    struct node *next;
};
struct node *head,*ptr,*temp,*newnode;

void create(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->next=NULL;
    if(head==NULL){
        head=ptr=newnode;
    }
    else{
        ptr->next=newnode;
        ptr=newnode;
    }
}

void display(){
    temp=head;
    while(temp!=NULL){
        printf("->%d",temp->data);
        temp=temp->next;
    }
}

void delbeg(){
    temp=head;
    head=head->next;
    free(temp);
}

void delend(){
    temp=head;
    struct node *pre;
    while (temp->next!=NULL)
    {
        pre=temp;
        temp=temp->next;
    }
    free(temp);
    pre->next=NULL;
}

void delsp(){
    struct node *nxt;
    temp=head;
    int pos,i=1;
    printf("Enter position : ");
    scanf("%d",&pos);
    while(i<pos-1){
        temp=temp->next;
        i++;
    }
    nxt=temp->next;
    temp->next=nxt->next;
    free(nxt);
}

int main(){
    int choice=1;
    while(choice!=0){
        create();
        printf("Do you want to continue? (1/0) : ");
        scanf("%d",&choice);
    }
    display();
    printf("\nDelete beginning\n");
    delbeg();
    display();
    printf("\ndelete end\n");
    delend();
    display();
    printf("\ndelete specified\n");
    delsp();
    display();
    return 0;
}