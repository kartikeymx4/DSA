#include<stdio.h>
#include<malloc.h>

struct node{
    int data;
    struct node *next;
};
struct node *newnode,*front,*rear;
void enq(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->next=NULL;
    if(rear==NULL){
        rear=front=newnode;
    }
    else{
        rear->next=newnode;
        rear=newnode;
    }
}
void deq(){
    struct node *temp;
    if(front==NULL){
        printf("Queue is empty");
    }
    else{
        temp=front;
        front=front->next;
        free(temp);
    }
}

void display(){
    struct node *ptr;
    ptr=front;
    while(ptr!=NULL){
        printf("->%d",ptr->data);
        ptr=ptr->next;
    }
}

void main(){
    enq();
    enq();
    enq();
    enq();
    enq();
    enq();
    enq();
    display();
    printf("\n");
    deq();
    display();
    printf("\n");
    deq();
    display();

}