#include<stdio.h>

int bs(int arr[],int n,int key){
    int l,r,mid;
    l=0;
    r=n-1;
    while(l<=r){
        mid=(l+r)/2;
        if(arr[mid]==key){
            return mid;
        }
        else if(key<arr[mid])
        r=mid-1;
        else
        l=mid+1;
    }
    return -1;
}

void main(){
    int a[10],n,key,in;
    printf("Enter the number of element you want to enter : ");
    scanf("%d",&n);
    printf("Enter array element : ");
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("Enter data you want to search in array : ");
    scanf("%d",&key);
    in=bs(a,n,key);
    if(in==-1){
        printf("Not found");
    }
    else{
        printf("found at index : %d",in);
    }
}