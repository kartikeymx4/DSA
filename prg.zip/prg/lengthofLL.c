#include<stdio.h>
#include<malloc.h>

struct node
{
    int data;
    struct node *next;
};
struct node *head,*newnode,*temp;
void create(){
    newnode=(struct node *)malloc(sizeof(struct node));
    printf("Enter value : ");
    scanf("%d",&newnode->data);
    newnode->next=NULL;
    if(head==NULL){
        head=temp=newnode;
    }
    else{
        temp->next=newnode;
        temp=temp->next;
    }
}

void display(){
    temp=head;
    while (temp!=0){
        printf("->%d",temp->data);
        temp=temp->next;
    }
}
void getlength(){
    temp=head;
    int cnt=0;
    while(temp!=NULL){
        cnt++;
        temp=temp->next;
    }
    printf("Length = %d ",cnt);
}
int main(){
    int choice=1;
    while(choice!=0){
        create();
        printf("Do uwant ti insert more elements (1/0) : ");
        scanf("%d",&choice);
    }
    display();
    printf("\n");
    getlength();
    return 0;
}