#include<stdio.h>
int partition(int arr[],int l,int h){
    int pivot=arr[l];
    int start=l,end=h;
    int temp;
    while(start<end){
        while(arr[start]<=pivot){
            start++;
        }
        while(arr[end]>pivot){
            end--;
        }
        if(start<end){
            temp=arr[end];
            arr[end]=arr[start];
            arr[start]=temp;
        }
    }
    temp=arr[l];
    arr[l]=arr[end];
    arr[end]=temp;
    return end;
}
void quicksort(int arr[],int l,int h){
    int loc;
    if(l<h){
        loc=partition(arr,l,h);
        quicksort(arr,l,loc-1);
        quicksort(arr,loc+1,h);
    }
}

void main(){
    int arr[] = {10, 7, 8, 9, 1, 5};
    int n = sizeof(arr) / sizeof(arr[0]);
    printf("Array\n");
    for(int i=0;i<n;i++){
        printf("%d\t",arr[i]);
    }
    quicksort(arr, 0, n - 1);
    printf("Sorted Array\n");
    for(int i=0;i<n;i++){
        printf("%d\t",arr[i]);
    }
}