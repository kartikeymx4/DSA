#include<stdio.h>
#include<malloc.h>
struct node
{
    int data;
    struct node *next;
};
struct node *top,*newnode;
void push(int val){
    newnode=(struct node*)malloc(sizeof(struct node));
    newnode->data=val;
    newnode->next=NULL;
    if(top==NULL){
        top=newnode;
    }
    else{
        newnode->next=top;
        top=newnode;
    }
}
void pop(){
    if(top==NULL)
    printf("Stack is empty");
    else if(top->next==NULL){
        free(top);
        printf("element deleted");
    }
    else{
        struct node *ptr;
        ptr=top;
        top=top->next;
        free(ptr);
    }
}

void display(){
    if(top==NULL)
    printf("stack is empty");
    else{
        struct node *ptr1;
        ptr1=top;
        while(ptr1->next!=NULL){
            printf("->%d",ptr1->data);
            ptr1=ptr1->next;
        }
        printf("->%d",ptr1->data);
    }
}

void main(){
    push(1);
    push(2);
    push(3);
    push(4);
    display();
    pop();
    printf("\n");
    display();
}