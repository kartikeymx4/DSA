#include<stdio.h>
#include<conio.h>
#include<malloc.h>
struct node{
    int data;
    struct node *pre,*next;
};
struct node *head,*tail,*temp,*newnode;
int cnt=0;
void create(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->pre=newnode->next=NULL;
    if(head==NULL){
        head=tail=newnode;
    }
    else{
        newnode->pre=tail;
        tail->next=newnode;
        tail=newnode;
    }
}
void display(){
    temp=head;
    while(temp!=NULL){
        printf("->%d",temp->data);
        temp=temp->next;
        cnt++;
    }
    printf("\n");
}

void insertbeg(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->pre=newnode->next=NULL;
    head->pre=newnode;
    newnode->next=head;
    head=newnode;
}

void insertend(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->next=newnode->pre=NULL;
    tail->next=newnode;
    newnode->pre=tail;
    tail=newnode;
}

void insertpos(){
    int pos;
    printf("Enter position : ");
    scanf("%d",&pos);
    if(pos<1||pos>cnt){
        printf("Invalid position");
    }
    else if(pos==1){
        insertbeg();
    }
    else{
        newnode=(struct node*)malloc(sizeof(struct node));
        printf("Enter data : ");
        scanf("%d",&newnode->data);
        temp=head;
        int i=1;
        while(i<pos-1){
            temp=temp->next;
            i++;
        }
        newnode->pre=temp;
        newnode->next=temp->next;
        temp->next=newnode;
        newnode->next->pre=newnode;
    }
}
int main(){
    int choice=1;
    while(choice){
        create();
        printf("Do you want to continue (0/1) : ");
        scanf("%d",&choice);
    }
    display();
    printf("\nInsert at beggining\n");
    insertbeg();
    display();
    printf("\nInsert at end\n");
    insertend();
    display();
    printf("\nInsert at position\n");
    insertpos();
    display();
    return 0;
}