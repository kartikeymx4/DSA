#include<stdio.h>

int main(){
    int arr[]={4,3,9,8,7,1};
    int temp,i,j;
    int n=sizeof(arr)/sizeof(arr[0]);
    printf("Array\n");
    for(int i=0;i<n;i++){
        printf("%d\t",arr[i]);
    }
    for(i=1;i<n;i++){
        temp=arr[i];
        j=i-1;
        while(j>=0 && arr[j]>temp){
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=temp;
    }
    printf("\nSorted Array\n");
    for(int i=0;i<n;i++){
        printf("%d\t",arr[i]);
    }
}