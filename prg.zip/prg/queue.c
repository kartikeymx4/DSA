#include<stdio.h>
#define n 5
int queue[n];
int front=-1,rear=-1;
void enqueue(int val){
    if(rear==n-1){
        printf("Overflow");
    }
    else if(rear==-1 && front==-1){
        rear=front=0;
        queue[rear]=val;
    }
    else{
        rear++;
        queue[rear]=val;
    }
}

void dequeue(){
    if(front==-1 && rear==-1){
        printf("Underflow");
    }
    else if(front==rear){
        front=rear=-1;
    }
    else{
        front++;
    }
}

void display(){
    int i;
    if(front==-1 && rear==-1){
        printf("Queue is empty");
    }
    else{
        for(i=front;i<rear+1;i++){
            printf("%d\t",queue[i]);
            
        }
        printf("\n");
    }
}

void main(){
    enqueue(2);
    enqueue(3);
    enqueue(7);
    enqueue(9);
    enqueue(6);
    display();
    dequeue();
    display();
    dequeue();
    display();
}