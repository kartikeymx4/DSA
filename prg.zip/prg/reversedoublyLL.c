#include<stdio.h>
#include<conio.h>
#include<malloc.h>

struct node{
    int data;
    struct node *pre,*next;
};
struct node *head,*tail,*temp,*ptr,*newnode;

void create(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->next=newnode->pre=NULL;
    if (head==NULL)
    {
        head=tail=newnode;
    }
    else{
        tail->next=newnode;
        newnode->pre=tail;
        tail=newnode;
    }
}

void display(){
    temp=head;
    while (temp!=NULL)
    {
        printf("->%d",temp->data);
        temp=temp->next;
    }
    printf("\n");
}

void reverse(){
    temp=head;
    while(temp!=NULL){
        ptr=temp->next;
        temp->next=temp->pre;
        temp->pre=ptr;
        temp=ptr;
    }
    temp=head;
    head=tail;
    tail=temp;
}

int main(){
    int ch=1;
    while(ch){
        create();
        printf("Do you want to continue (1/0)");
        scanf("%d",&ch);
    }
    display();
    printf("\n=======Reverse=======\n");
    reverse();
    display();
    return 0;
}