#include <stdio.h>
#include <malloc.h>

struct node
{
    int data;
    struct node *next;
};
struct node *head, *temp, *newnode;

void create()
{
    int ch = 1;
    while (ch)
    {
        newnode = (struct node *)malloc(sizeof(struct node));
        printf("Enter data : ");
        scanf("%d", &newnode->data);
        newnode->next = NULL;
        if (head == NULL)
        {
            head = temp = newnode;
            temp->next=newnode;
        }
        else
        {
            temp->next = newnode;
            temp = newnode;
        }
        printf("Do you want to continue (1/0)");
        scanf("%d", &ch);
    }
    temp->next = head;
    printf("head=%d\ttempnext=%d\n",head,temp->next);
}

void display(){
    temp=head;
    while(temp->next!=head){
        printf("->%d",temp->data);
        temp=temp->next;
    }
    printf("->%d",temp->data);
}

int main(){
    create();
    display();
    return 0;
}