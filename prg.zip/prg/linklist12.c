//Insertion in linked list
#include<stdio.h>
#include<conio.h>
#include<malloc.h>

struct node{
    int data;
    struct node *next;
};
struct node *head,*newnode,*ptr;

void create(){
    newnode=(struct node *)malloc(sizeof(struct node));
    printf("Enter data u want insert : ");
    scanf("%d",&newnode->data);
    newnode->next=NULL;
    if(head==NULL){
        head=ptr=newnode;   
    }
    else{
        ptr->next=newnode;
        ptr=newnode;
    }
}

void display(){
    ptr=head;
    while(ptr!=NULL){
        printf("->%d",ptr->data);
        ptr=ptr->next;
    }
}

void beg(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->next=head;
    head=newnode;
}

void end(){
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    newnode->next=NULL;
    ptr=head;
    while(ptr->next!=NULL){
        ptr=ptr->next;
    }
    ptr->next=newnode;
}

void pos(){
    int pos,i=1;
    printf("Enter position where you want to enter : ");
    scanf("%d",&pos);
    newnode=(struct node*)malloc(sizeof(struct node));
    printf("Enter data : ");
    scanf("%d",&newnode->data);
    ptr=head;
    while(i<pos){
        ptr=ptr->next;
        i++;
    }
    newnode->next=ptr->next;
    ptr->next=newnode;
}

int main(){
    int choice=1;
    while(choice!=0){
        create();
        printf("Do you want to enter more(1/0)");
        scanf("%d",&choice);
    }
    display();
    printf("\n=========Enter in beginning======\n");
    beg();
    printf("\n");
    display();
    printf("\n");
    printf("=========Enter in end========\n");
    end();
    printf("\n");
    display();
    printf("\n");
    printf("=========Enter in position========\n");
    pos();
    printf("\n");
    display();
    printf("\n");
    return 0;
}